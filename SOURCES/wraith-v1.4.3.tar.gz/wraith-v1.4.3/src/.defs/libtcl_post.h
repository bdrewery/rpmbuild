extern "C" {
#undef Tcl_CreateCommand
typedef Tcl_Command (*Tcl_CreateCommand_t)(Tcl_Interp *, const char *, Tcl_CmdProc *, ClientData, Tcl_CmdDeleteProc *);
Tcl_Command Tcl_CreateCommand (Tcl_Interp * x0, const char * x1, Tcl_CmdProc * x2, ClientData x3, Tcl_CmdDeleteProc * x4);
#undef Tcl_CreateInterp
typedef Tcl_Interp * (*Tcl_CreateInterp_t)(void);
Tcl_Interp * Tcl_CreateInterp (void);
#undef Tcl_DeleteInterp
typedef void (*Tcl_DeleteInterp_t)(Tcl_Interp *);
void Tcl_DeleteInterp (Tcl_Interp * x0);
#undef Tcl_Eval
typedef int (*Tcl_Eval_t)(Tcl_Interp *, const char *);
int Tcl_Eval (Tcl_Interp * x0, const char * x1);
#undef Tcl_FindExecutable
typedef void (*Tcl_FindExecutable_t)(const char *);
void Tcl_FindExecutable (const char * x0);
#undef Tcl_GetStringResult
typedef const char * (*Tcl_GetStringResult_t)(Tcl_Interp *);
const char * Tcl_GetStringResult (Tcl_Interp * x0);
#undef Tcl_Init
typedef int (*Tcl_Init_t)(Tcl_Interp *);
int Tcl_Init (Tcl_Interp * x0);
}
