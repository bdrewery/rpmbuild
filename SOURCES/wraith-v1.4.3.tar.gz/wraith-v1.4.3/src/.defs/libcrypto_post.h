extern "C" {
#undef AES_cbc_encrypt
typedef void (*AES_cbc_encrypt_t)(const unsigned char *, unsigned char *, size_t, const AES_KEY *, unsigned char *, const int);
void AES_cbc_encrypt (const unsigned char * x0, unsigned char * x1, size_t x2, const AES_KEY * x3, unsigned char * x4, const int x5);
#undef AES_decrypt
typedef void (*AES_decrypt_t)(const unsigned char *, unsigned char *, const AES_KEY *);
void AES_decrypt (const unsigned char * x0, unsigned char * x1, const AES_KEY * x2);
#undef AES_encrypt
typedef void (*AES_encrypt_t)(const unsigned char *, unsigned char *, const AES_KEY *);
void AES_encrypt (const unsigned char * x0, unsigned char * x1, const AES_KEY * x2);
#undef AES_set_decrypt_key
typedef int (*AES_set_decrypt_key_t)(const unsigned char *, const int, AES_KEY *);
int AES_set_decrypt_key (const unsigned char * x0, const int x1, AES_KEY * x2);
#undef AES_set_encrypt_key
typedef int (*AES_set_encrypt_key_t)(const unsigned char *, const int, AES_KEY *);
int AES_set_encrypt_key (const unsigned char * x0, const int x1, AES_KEY * x2);
#undef BF_decrypt
typedef void (*BF_decrypt_t)(unsigned int *,const BF_KEY *);
void BF_decrypt (unsigned int * x0,const BF_KEY * x1);
#undef BF_encrypt
typedef void (*BF_encrypt_t)(unsigned int *,const BF_KEY *);
void BF_encrypt (unsigned int * x0,const BF_KEY * x1);
#undef BF_set_key
typedef void (*BF_set_key_t)(BF_KEY *, int, const unsigned char *);
void BF_set_key (BF_KEY * x0, int x1, const unsigned char * x2);
#undef BN_bin2bn
typedef BIGNUM * (*BN_bin2bn_t)(const unsigned char *,int,BIGNUM *);
BIGNUM * BN_bin2bn (const unsigned char * x0,int x1,BIGNUM * x2);
#undef BN_bn2bin
typedef int (*BN_bn2bin_t)(const BIGNUM *, unsigned char *);
int BN_bn2bin (const BIGNUM * x0, unsigned char * x1);
#undef BN_clear_free
typedef void (*BN_clear_free_t)(BIGNUM *);
void BN_clear_free (BIGNUM * x0);
#undef BN_dec2bn
typedef int (*BN_dec2bn_t)(BIGNUM **, const char *);
int BN_dec2bn (BIGNUM ** x0, const char * x1);
#undef BN_dup
typedef BIGNUM * (*BN_dup_t)(const BIGNUM *);
BIGNUM * BN_dup (const BIGNUM * x0);
#undef BN_hex2bn
typedef int (*BN_hex2bn_t)(BIGNUM **, const char *);
int BN_hex2bn (BIGNUM ** x0, const char * x1);
#undef BN_num_bits
typedef int (*BN_num_bits_t)(const BIGNUM *);
int BN_num_bits (const BIGNUM * x0);
#undef CRYPTO_cleanup_all_ex_data
typedef void (*CRYPTO_cleanup_all_ex_data_t)(void);
void CRYPTO_cleanup_all_ex_data (void);
#undef DH_compute_key
typedef int (*DH_compute_key_t)(unsigned char *,const BIGNUM *,DH *);
int DH_compute_key (unsigned char * x0,const BIGNUM * x1,DH * x2);
#undef DH_free
typedef void (*DH_free_t)(DH *);
void DH_free (DH * x0);
#undef DH_generate_key
typedef int (*DH_generate_key_t)(DH *);
int DH_generate_key (DH * x0);
#undef DH_new
typedef DH * (*DH_new_t)(void);
DH * DH_new (void);
#undef DH_size
typedef int (*DH_size_t)(const DH *);
int DH_size (const DH * x0);
#undef ERR_error_string
typedef char * (*ERR_error_string_t)(unsigned long,char *);
char * ERR_error_string (unsigned long x0,char * x1);
#undef ERR_free_strings
typedef void (*ERR_free_strings_t)(void);
void ERR_free_strings (void);
#undef ERR_get_error
typedef unsigned long (*ERR_get_error_t)(void);
unsigned long ERR_get_error (void);
#undef EVP_cleanup
typedef void (*EVP_cleanup_t)(void);
void EVP_cleanup (void);
#undef MD5_Final
typedef int (*MD5_Final_t)(unsigned char *, MD5_CTX *);
int MD5_Final (unsigned char * x0, MD5_CTX * x1);
#undef MD5_Init
typedef int (*MD5_Init_t)(MD5_CTX *);
int MD5_Init (MD5_CTX * x0);
#undef MD5_Update
typedef int (*MD5_Update_t)(MD5_CTX *, const void *, size_t);
int MD5_Update (MD5_CTX * x0, const void * x1, size_t x2);
#undef OPENSSL_cleanse
typedef void (*OPENSSL_cleanse_t)(void *, size_t);
void OPENSSL_cleanse (void * x0, size_t x1);
#undef RAND_file_name
typedef const char * (*RAND_file_name_t)(char *,size_t);
const char * RAND_file_name (char * x0,size_t x1);
#undef RAND_load_file
typedef int (*RAND_load_file_t)(const char *,long);
int RAND_load_file (const char * x0,long x1);
#undef RAND_seed
typedef void (*RAND_seed_t)(const void *,int);
void RAND_seed (const void * x0,int x1);
#undef RAND_status
typedef int (*RAND_status_t)(void);
int RAND_status (void);
#undef RAND_write_file
typedef int (*RAND_write_file_t)(const char *);
int RAND_write_file (const char * x0);
#undef SHA1_Final
typedef int (*SHA1_Final_t)(unsigned char *, SHA_CTX *);
int SHA1_Final (unsigned char * x0, SHA_CTX * x1);
#undef SHA1_Init
typedef int (*SHA1_Init_t)(SHA_CTX *);
int SHA1_Init (SHA_CTX * x0);
#undef SHA1_Update
typedef int (*SHA1_Update_t)(SHA_CTX *, const void *, size_t);
int SHA1_Update (SHA_CTX * x0, const void * x1, size_t x2);
#undef SHA256_Final
typedef int (*SHA256_Final_t)(unsigned char *, SHA256_CTX *);
int SHA256_Final (unsigned char * x0, SHA256_CTX * x1);
#undef SHA256_Init
typedef int (*SHA256_Init_t)(SHA256_CTX *);
int SHA256_Init (SHA256_CTX * x0);
#undef SHA256_Update
typedef int (*SHA256_Update_t)(SHA256_CTX *, const void *, size_t);
int SHA256_Update (SHA256_CTX * x0, const void * x1, size_t x2);
}
