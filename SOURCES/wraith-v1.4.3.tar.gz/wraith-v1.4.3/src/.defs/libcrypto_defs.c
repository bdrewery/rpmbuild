extern "C" {
void AES_cbc_encrypt (const unsigned char * x0, unsigned char * x1, size_t x2, const AES_KEY * x3, unsigned char * x4, const int x5) {
  return DLSYM_VAR(AES_cbc_encrypt)(x0, x1, x2, x3, x4, x5);
}
void AES_decrypt (const unsigned char * x0, unsigned char * x1, const AES_KEY * x2) {
  return DLSYM_VAR(AES_decrypt)(x0, x1, x2);
}
void AES_encrypt (const unsigned char * x0, unsigned char * x1, const AES_KEY * x2) {
  return DLSYM_VAR(AES_encrypt)(x0, x1, x2);
}
int AES_set_decrypt_key (const unsigned char * x0, const int x1, AES_KEY * x2) {
  return DLSYM_VAR(AES_set_decrypt_key)(x0, x1, x2);
}
int AES_set_encrypt_key (const unsigned char * x0, const int x1, AES_KEY * x2) {
  return DLSYM_VAR(AES_set_encrypt_key)(x0, x1, x2);
}
void BF_decrypt (unsigned int * x0,const BF_KEY * x1) {
  return DLSYM_VAR(BF_decrypt)(x0, x1);
}
void BF_encrypt (unsigned int * x0,const BF_KEY * x1) {
  return DLSYM_VAR(BF_encrypt)(x0, x1);
}
void BF_set_key (BF_KEY * x0, int x1, const unsigned char * x2) {
  return DLSYM_VAR(BF_set_key)(x0, x1, x2);
}
BIGNUM * BN_bin2bn (const unsigned char * x0,int x1,BIGNUM * x2) {
  return DLSYM_VAR(BN_bin2bn)(x0, x1, x2);
}
int BN_bn2bin (const BIGNUM * x0, unsigned char * x1) {
  return DLSYM_VAR(BN_bn2bin)(x0, x1);
}
void BN_clear_free (BIGNUM * x0) {
  return DLSYM_VAR(BN_clear_free)(x0);
}
int BN_dec2bn (BIGNUM ** x0, const char * x1) {
  return DLSYM_VAR(BN_dec2bn)(x0, x1);
}
BIGNUM * BN_dup (const BIGNUM * x0) {
  return DLSYM_VAR(BN_dup)(x0);
}
int BN_hex2bn (BIGNUM ** x0, const char * x1) {
  return DLSYM_VAR(BN_hex2bn)(x0, x1);
}
int BN_num_bits (const BIGNUM * x0) {
  return DLSYM_VAR(BN_num_bits)(x0);
}
void CRYPTO_cleanup_all_ex_data (void) {
  return DLSYM_VAR(CRYPTO_cleanup_all_ex_data)();
}
int DH_compute_key (unsigned char * x0,const BIGNUM * x1,DH * x2) {
  return DLSYM_VAR(DH_compute_key)(x0, x1, x2);
}
void DH_free (DH * x0) {
  return DLSYM_VAR(DH_free)(x0);
}
int DH_generate_key (DH * x0) {
  return DLSYM_VAR(DH_generate_key)(x0);
}
DH * DH_new (void) {
  return DLSYM_VAR(DH_new)();
}
int DH_size (const DH * x0) {
  return DLSYM_VAR(DH_size)(x0);
}
char * ERR_error_string (unsigned long x0,char * x1) {
  return DLSYM_VAR(ERR_error_string)(x0, x1);
}
void ERR_free_strings (void) {
  return DLSYM_VAR(ERR_free_strings)();
}
unsigned long ERR_get_error (void) {
  return DLSYM_VAR(ERR_get_error)();
}
void EVP_cleanup (void) {
  return DLSYM_VAR(EVP_cleanup)();
}
int MD5_Final (unsigned char * x0, MD5_CTX * x1) {
  return DLSYM_VAR(MD5_Final)(x0, x1);
}
int MD5_Init (MD5_CTX * x0) {
  return DLSYM_VAR(MD5_Init)(x0);
}
int MD5_Update (MD5_CTX * x0, const void * x1, size_t x2) {
  return DLSYM_VAR(MD5_Update)(x0, x1, x2);
}
void OPENSSL_cleanse (void * x0, size_t x1) {
  return DLSYM_VAR(OPENSSL_cleanse)(x0, x1);
}
const char * RAND_file_name (char * x0,size_t x1) {
  return DLSYM_VAR(RAND_file_name)(x0, x1);
}
int RAND_load_file (const char * x0,long x1) {
  return DLSYM_VAR(RAND_load_file)(x0, x1);
}
void RAND_seed (const void * x0,int x1) {
  return DLSYM_VAR(RAND_seed)(x0, x1);
}
int RAND_status (void) {
  return DLSYM_VAR(RAND_status)();
}
int RAND_write_file (const char * x0) {
  return DLSYM_VAR(RAND_write_file)(x0);
}
int SHA1_Final (unsigned char * x0, SHA_CTX * x1) {
  return DLSYM_VAR(SHA1_Final)(x0, x1);
}
int SHA1_Init (SHA_CTX * x0) {
  return DLSYM_VAR(SHA1_Init)(x0);
}
int SHA1_Update (SHA_CTX * x0, const void * x1, size_t x2) {
  return DLSYM_VAR(SHA1_Update)(x0, x1, x2);
}
int SHA256_Final (unsigned char * x0, SHA256_CTX * x1) {
  return DLSYM_VAR(SHA256_Final)(x0, x1);
}
int SHA256_Init (SHA256_CTX * x0) {
  return DLSYM_VAR(SHA256_Init)(x0);
}
int SHA256_Update (SHA256_CTX * x0, const void * x1, size_t x2) {
  return DLSYM_VAR(SHA256_Update)(x0, x1, x2);
}
}
