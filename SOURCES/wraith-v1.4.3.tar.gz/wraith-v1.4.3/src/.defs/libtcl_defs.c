extern "C" {
Tcl_Command Tcl_CreateCommand (Tcl_Interp * x0, const char * x1, Tcl_CmdProc * x2, ClientData x3, Tcl_CmdDeleteProc * x4) {
  return DLSYM_VAR(Tcl_CreateCommand)(x0, x1, x2, x3, x4);
}
Tcl_Interp * Tcl_CreateInterp (void) {
  return DLSYM_VAR(Tcl_CreateInterp)();
}
void Tcl_DeleteInterp (Tcl_Interp * x0) {
  return DLSYM_VAR(Tcl_DeleteInterp)(x0);
}
int Tcl_Eval (Tcl_Interp * x0, const char * x1) {
  return DLSYM_VAR(Tcl_Eval)(x0, x1);
}
void Tcl_FindExecutable (const char * x0) {
  return DLSYM_VAR(Tcl_FindExecutable)(x0);
}
const char * Tcl_GetStringResult (Tcl_Interp * x0) {
  return DLSYM_VAR(Tcl_GetStringResult)(x0);
}
int Tcl_Init (Tcl_Interp * x0) {
  return DLSYM_VAR(Tcl_Init)(x0);
}
}
