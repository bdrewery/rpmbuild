extern "C" {
#undef SSL_CTX_ctrl
typedef long (*SSL_CTX_ctrl_t)(SSL_CTX *,int, long, void *);
long SSL_CTX_ctrl (SSL_CTX * x0,int x1, long x2, void * x3);
#undef SSL_CTX_free
typedef void (*SSL_CTX_free_t)(SSL_CTX *);
void SSL_CTX_free (SSL_CTX * x0);
#undef SSL_CTX_new
typedef SSL_CTX * (*SSL_CTX_new_t)(const SSL_METHOD *);
SSL_CTX * SSL_CTX_new (const SSL_METHOD * x0);
#undef SSL_CTX_set_cipher_list
typedef int (*SSL_CTX_set_cipher_list_t)(SSL_CTX *,const char *);
int SSL_CTX_set_cipher_list (SSL_CTX * x0,const char * x1);
#undef SSL_CTX_set_tmp_dh_callback
void SSL_CTX_set_tmp_dh_callback (SSL_CTX* x0, dh_callback_t x1);
#undef SSL_connect
typedef int (*SSL_connect_t)(SSL *);
int SSL_connect (SSL * x0);
#undef SSL_free
typedef void (*SSL_free_t)(SSL *);
void SSL_free (SSL * x0);
#undef SSL_get_error
typedef int (*SSL_get_error_t)(const SSL *,int);
int SSL_get_error (const SSL * x0,int x1);
#undef SSL_library_init
typedef int (*SSL_library_init_t)(void);
int SSL_library_init (void);
#undef SSL_load_error_strings
typedef void (*SSL_load_error_strings_t)(void);
void SSL_load_error_strings (void);
#undef SSL_new
typedef SSL * (*SSL_new_t)(SSL_CTX *);
SSL * SSL_new (SSL_CTX * x0);
#undef SSL_pending
typedef int (*SSL_pending_t)(const SSL *);
int SSL_pending (const SSL * x0);
#undef SSL_read
typedef int (*SSL_read_t)(SSL *,void *,int);
int SSL_read (SSL * x0,void * x1,int x2);
#undef SSL_set_fd
typedef int (*SSL_set_fd_t)(SSL *, int);
int SSL_set_fd (SSL * x0, int x1);
#undef SSL_shutdown
typedef int (*SSL_shutdown_t)(SSL *);
int SSL_shutdown (SSL * x0);
#undef SSL_write
typedef int (*SSL_write_t)(SSL *,const void *,int);
int SSL_write (SSL * x0,const void * x1,int x2);
#undef SSLv23_client_method
typedef const SSL_METHOD * (*SSLv23_client_method_t)(void);
const SSL_METHOD * SSLv23_client_method (void);
}
