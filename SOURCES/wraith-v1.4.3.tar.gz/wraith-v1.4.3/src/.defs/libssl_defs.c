extern "C" {
long SSL_CTX_ctrl (SSL_CTX * x0,int x1, long x2, void * x3) {
  return DLSYM_VAR(SSL_CTX_ctrl)(x0, x1, x2, x3);
}
void SSL_CTX_free (SSL_CTX * x0) {
  return DLSYM_VAR(SSL_CTX_free)(x0);
}
SSL_CTX * SSL_CTX_new (const SSL_METHOD * x0) {
  return DLSYM_VAR(SSL_CTX_new)(x0);
}
int SSL_CTX_set_cipher_list (SSL_CTX * x0,const char * x1) {
  return DLSYM_VAR(SSL_CTX_set_cipher_list)(x0, x1);
}
void SSL_CTX_set_tmp_dh_callback (SSL_CTX* x0, dh_callback_t x1) {
  return DLSYM_VAR(SSL_CTX_set_tmp_dh_callback)(x0, x1);
}
int SSL_connect (SSL * x0) {
  return DLSYM_VAR(SSL_connect)(x0);
}
void SSL_free (SSL * x0) {
  return DLSYM_VAR(SSL_free)(x0);
}
int SSL_get_error (const SSL * x0,int x1) {
  return DLSYM_VAR(SSL_get_error)(x0, x1);
}
int SSL_library_init (void) {
  return DLSYM_VAR(SSL_library_init)();
}
void SSL_load_error_strings (void) {
  return DLSYM_VAR(SSL_load_error_strings)();
}
SSL * SSL_new (SSL_CTX * x0) {
  return DLSYM_VAR(SSL_new)(x0);
}
int SSL_pending (const SSL * x0) {
  return DLSYM_VAR(SSL_pending)(x0);
}
int SSL_read (SSL * x0,void * x1,int x2) {
  return DLSYM_VAR(SSL_read)(x0, x1, x2);
}
int SSL_set_fd (SSL * x0, int x1) {
  return DLSYM_VAR(SSL_set_fd)(x0, x1);
}
int SSL_shutdown (SSL * x0) {
  return DLSYM_VAR(SSL_shutdown)(x0);
}
int SSL_write (SSL * x0,const void * x1,int x2) {
  return DLSYM_VAR(SSL_write)(x0, x1, x2);
}
const SSL_METHOD * SSLv23_client_method (void) {
  return DLSYM_VAR(SSLv23_client_method)();
}
}
