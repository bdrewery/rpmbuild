#ifndef _GARBLE_H
#define _GARBLE_H

#ifdef DEBUG
#define STR(x) x
#endif

const char *degarble(int, const char *);

#endif /* !_GARBLE_H */
