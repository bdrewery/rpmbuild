#ifndef _THREAD_H
#define _THREAD_H

void init_thread(int);

#endif /* !_THREAD_H */
