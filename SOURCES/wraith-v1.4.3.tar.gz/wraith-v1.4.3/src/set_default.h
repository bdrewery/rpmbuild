#define DEFAULT_ALIAS "\
bc botcmd,\
bl botcmd ?,\
gc botcmd *,\
bm botmsg,\
bs botset ,\
op botcmd ? op,\
cq clearqueue play,\
+list set +,\
-list set -,\
list set list,\
-bot -user,\
+bot newleaf"

#define DEFAULT_SERVERS "\
irc.choopa.net,\
irc.colosolutions.net,\
irc.eversible.com,\
irc.mzima.net,\
irc.paraphysics.net,\
irc.servercentral.net,\
irc.shoutcast.com,\
irc.umich.edu,\
irc2.choopa.net,\
efnet.cs.hut.fi,\
efnet.port80.se,\
efnet.portlane.se,\
efnet.xs4all.nl,\
irc.ac.za,\
irc.du.se,\
irc.efnet.fr,\
irc.efnet.pl,\
irc.homelien.no,\
irc.inet.tele.dk,\
irc.underworld.no,\
irc.arcti.ca,\
irc.choopa.ca,\
irc.teksavvy.ca"

#define DEFAULT_SERVERS6 "\
efnet.ipv6.port80.se,\
efnet.ipv6.xs4all.nl,\
efnet.portlane.se,\
irc.ac.za,\
irc.choopa.ca,\
irc.choopa.net,\
irc.inet.tele.dk,\
irc.ipv6.homelien.no,\
irc.ipv6.paraphysics.net,\
irc.underworld.no,\
irc.teksavvy.ca"

#define DEFAULT_SERVERS_SSL "\
efnet.xs4all.nl,\
irc.choopa.ca:9999,\
irc.choopa.net:9999,\
irc.eversible.com:9999,\
irc.paraphysics.net,\
irc.servercentral.net:9999,\
irc.shoutcast.com:8000,\
irc.umich.edu:9999,\
irc.underworld.no"

#define DEFAULT_SERVERS6_SSL "\
efnet.ipv6.xs4all.nl,\
irc.choopa.ca:9999,\
irc.choopa.net:9999,\
irc.ipv6.paraphysics.net,\
irc.underworld.no"

#define DEFAULT_RBL "\
dnsbl.ahbl.org,\
dnsbl.proxybl.org,\
rbl.efnetrbl.org,\
tor.efnet.org,\
dnsbl.swiftbl.org,\
xbl.spamhaus.org,\
rbl.efnetpro.com"

