#ifndef _DIRNAME_H
#define _DIRNAME_H

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#define dirname my_dirname

char *dirname(const char *);
#endif /* !_DIRNAME_H */

