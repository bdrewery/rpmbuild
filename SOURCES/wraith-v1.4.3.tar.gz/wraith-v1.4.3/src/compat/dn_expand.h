#ifndef _DN_EXPAND_H
#define _DN_EXPAND_H

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

int my_dn_expand(const unsigned char *, const unsigned char *, const unsigned char *, char *, int);

#endif /* !_DN_EXPAND_H */

